int declaration_type; // To pass variable type in yacc
int totalCount = 4096; // Memory address of next variable

struct Gsymbol {
    char* name;     // name of the variable
    int type;       // type of the variable
    int size;       // size of the type of the variable
    int binding;    // stores the static memory address allocated to the variable
    int rows;
    int cols;
    int isPtr;
    struct Gsymbol *next;
};

struct Gsymbol* GLookup(char * name); // Returns a pointer to the symbol table entry for the variable, returns NULL otherwise.
void GInstall(char *name, int type, int size,int isPtr); // Creates a symbol table entry.
void GInstall2D(char *name, int type, int rows,int cols); // Creates a symbol table entry.
void printSymbolTable(); 
struct Gsymbol *Ghead, *Gtail;